@extends('layouts.app')

@section('content')
   <div class="container col-md-12">
    <div class="row">
        <div class="col-md-12 col-md-offset-0">
            @if(Session::has('message'))
            <div class="breadLine">
            <i class="fa fa-save"> </i> <span style="color:green">{!!Session::get('message')!!} </span>
            </div>
            @endif
            <div class="panel panel-default">
                <div class="panel-heading"><i class="fa fa-home"> </i> Form Add Profile </div>
                <div class="panel-body">
                   {!! Form::open(array('url' => ['admin/gallery/update',$editdata->g_id],'enctype'=>'multipart/form-data','file'=>'true')) !!}
                    
                    <input type="hidden" name="_token" value="{{ csrf_token() }}">
                        <div class="form-group{{ $errors->has('g_name') ? ' has-error' : '' }}">
                            <label style="margin-top: 10px;" for="g_name" class="col-md-2 control-label"> Gallery Name  :</label>

                            <div class="col-md-4">
                                <input id="position_name" type="text" class="form-control" name="g_name" value="{{ $editdata->g_name }}">
                                @if($errors->has('g_name'))
                                        <span style="color:red">{!!$errors->first('g_name')!!} </span>
                                @endif
                            </div>
                        </div>                 
                        
                        <div class="form-group{{ $errors->has('g_image') ? ' has-error' : '' }}">
                            <label style="margin-top: 10px;" for="g_image" class="col-md-2 control-label">Image :</label>

                            <div class="col-md-2">
                                <input id="images" type="file" class="form-control" name="g_image" value="{{ $editdata->g_image }}">
                                @if($errors->has('g_image'))
                                        <span style="color:red">{!!$errors->first('g_image')!!} </span>
                                @endif
                            </div>
                            <div class="col-md-2"><img width="40" src="{{Url('')}}/admin/kcfinder/upload/images/{{ $editdata->g_image }}" /> </div>
                        </div>    
                     <div style="clear: both;"></div>
                        <div class="form-group{{ $errors->has('status') ? ' has-error' : '' }}">
                            <label style="margin-top: 10px;" for="status" class="col-md-2 control-label">Status :</label>

                            <div class="col-md-4">
                               <select name="status" id="status" class="form-control">
                                    <option value="1" <?php if ($editdata->status==1) echo 'selected="selected"';?> ><?php echo "Publish"; ?></option>
                                    <option value="0" <?php if ($editdata->status==0) echo 'selected="selected"';?> ><?php echo "Unpublish"; ?></option>
                                </select>

                                @if($errors->has('status'))
                                        <span style="color:red">{!!$errors->first('status')!!} </span>
                                @endif
                            </div>
                        </div>
                        <div class="form-group{{ $errors->has('ordering') ? ' has-error' : '' }}">
                            <label for="ordering" style="margin-top: 10px;" class="col-md-2 control-label"> Ordering :</label>

                            <div class="col-md-4">
                                <input id="text" type="text" class="form-control" name="ordering" value="{{ $editdata->ordering }}">

                                @if($errors->has('ordering'))
                                        <span style="color:red">{!!$errors->first('ordering')!!} </span>
                                @endif
                            </div>
                        </div>
                        <div style="clear: both;"></div>
                        <div style="margin-top: 30px;" class="form-group{{ $errors->has('description') ? ' has-error' : '' }}">
                            <label style="margin-top: 10px;" for="description" class="col-md-2 control-label">Description :</label>

                            <div class="col-md-10">
                                <textarea id="editor" name="description" >{{ $editdata->description }} </textarea>

                                @if($errors->has('description'))
                                        <span style="color:red">{!!$errors->first('description')!!} </span>
                                @endif
                            </div>
                        </div>
                            
                        <div class="form-group" >
                            <div class="col-md-4"></div>    
                            <div style="clear: both;"></div>
                            <div class="col-md-8" style="margin: 10px;    float: right;">
                                <button class="btn btn-primary" type="submit" name="save"  value="2"><i class="fa fa-sign-in"> </i> Save & Close </button>
				<button class="btn btn-primary" type="submit" name="save"  value="3"><i class="fa fa-check-circle-o"> </i>  Save & New </button>
				<a href="{{ url('/admin/gallery') }}"><button class="btn btn-danger" type="button"><i class="fa fa-close"> </i>  Cancel</button></a>
                            </div>
                        </div>    
                        
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</div>

@endsection